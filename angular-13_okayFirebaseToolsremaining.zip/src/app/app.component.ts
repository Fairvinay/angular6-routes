import { Component, OnInit } from '@angular/core';
import {FirebaseUIModule, firebase, firebaseui} from 'firebaseui-angular';
//import { getAuth, signInWithPopup, GoogleAuthProvider } from "@firebase/auth";
//import { AngularFireAuthModule } from '@angular/fire/compat/auth';
	import {
  getAuth,
  GoogleAuthProvider,
  signInWithPopup,
} from '@angular/fire/auth';

//import { AngularFireAuth } from '@angular/fire/auth' ;
import * as auth from 'firebase/auth';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {

 provider = new auth.GoogleAuthProvider();
 // afAuth :auth.Auth = getAuth();

constructor(){
	this.provider.setCustomParameters({
	'login_hint': 'user@example.com'
	});

}


ngOnInit() {

	console.log(" Google Authentication in process ... ");
	
	//const auth = getAuth();
	/*
  signInWithPopup(this.afAuth, this.provider)
  .then((result) => {
    // This gives you a Google Access Token. You can use it to access the Google API.
    const credential = GoogleAuthProvider.credentialFromResult(result);
    const token = credential?.accessToken;
    // The signed-in user info.
    const user = result.user;
	console.log(" Signed in User ... "+JSON.stringify(user));
    // IdP data available using getAdditionalUserInfo(result)
    // ...
  }).catch((error) => {
    // Handle Errors here.
    const errorCode = error.code;
    const errorMessage = error.message;
    // The email of the user's account used.
    const email = error.customData.email;
	console.log("Failed loging  ... "+JSON.stringify(errorCode+" "+errorMessage+" "+email));
    // The AuthCredential type that was used.
    const credential = GoogleAuthProvider.credentialFromError(error);
	console.log("Failed AuthType  ... "+JSON.stringify(credential));
    // ...
  }); */
}


}
