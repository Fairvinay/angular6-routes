import {FirebaseUIModule, firebase, firebaseui} from 'firebaseui-angular';


const firebaseUiAuthConfig: firebaseui.auth.Config = {
    signInFlow: 'popup',
    signInOptions: [
        firebase.auth.GoogleAuthProvider.PROVIDER_ID,
        {
            scopes: [
                'public_profile',
                'email'/*,
                'user_likes',
                'user_friends'*/
            ],
            customParameters: {
                'auth_type': 'reauthenticate'
            },
            provider:       firebase.auth.FacebookAuthProvider.PROVIDER_ID
        },
        firebase.auth.TwitterAuthProvider.PROVIDER_ID,
        firebase.auth.GithubAuthProvider.PROVIDER_ID,
        {
            requireDisplayName: false,
            provider: firebase.auth.EmailAuthProvider.PROVIDER_ID
        },
        firebase.auth.PhoneAuthProvider.PROVIDER_ID,
        firebaseui.auth.AnonymousAuthProvider.PROVIDER_ID
    ],
    //term of service
    tosUrl: 'https://localhost:7829/',
    //privacy url
    privacyPolicyUrl: 'https://localhost:7829/',
    //credentialHelper:             firebaseui.auth.CredentialHelper.ACCOUNT_CHOOSER_COM
    credentialHelper: firebaseui.auth.CredentialHelper.NONE
};
export const environment = {
  production: true,
  
    firebase: {
  	
	 apiKey: "AIzaSyCQA1pL_d8I1474OoQme1vZmJutOK4jWeo",
  authDomain: "glaubhanta-1c30f.firebaseapp.com",
  projectId: "glaubhanta-1c30f",
  storageBucket: "glaubhanta-1c30f.appspot.com",
  messagingSenderId: "392194816848",
  appId: "1:392194816848:web:f59b4145225bc59aea0a55",
  measurementId: "G-K88YLPWEBK"
	
	
	
  },
  firebaseUiAuthConfig : firebaseUiAuthConfig
  
};
