# Spring Boot Hello World Example
Get started with the Spring Boot application, a hello world example.

https://mkyong.com/spring-boot/spring-boot-hello-world-example/

## 1. How to start
```bash
$ git clone [https://github.com/mkyong/spring-boot.git](https://github.com/mkyong/spring-boot.git)

$ cd spring-boot-hello-world

# Tomcat started at 8080
$ mvn spring-boot:run

# test
curl localhost:8080

```


