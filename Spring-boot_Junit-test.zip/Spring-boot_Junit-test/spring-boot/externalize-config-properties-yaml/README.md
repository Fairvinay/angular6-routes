# Spring Boot @ConfigurationProperties example

Article link : https://www.mkyong.com/spring-boot/spring-boot-configurationproperties-example/

## 1. How to start
```
$ git clone [https://github.com/mkyong/spring-boot.git](https://github.com/mkyong/spring-boot.git)
$ cd externalize-config-properties-yaml
$ mvn spring-boot:run

access localhost:8080
```