# Spring Boot WebFlux + Thymeleaf

Article link : https://www.mkyong.com/spring-boot/spring-boot-webflux-thymeleaf-reactive-example/

## 1. How to start
```
$ mvn spring-boot:run
```

Access http://localhost:8080
